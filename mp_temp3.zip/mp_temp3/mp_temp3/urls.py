"""mp URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views

from users import views as user_views
from app import views as app_view

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', app_view.index, name='index'),
    path('register/', user_views.register, name='register'),
    path('studentupdateprofile/', user_views.studentupdateprofile, name='studentupdateprofile'),

    path('studentsignup/', user_views.studentsignup, name='studentsignup'),
    path('tposignup/', user_views.tposignup, name='tposignup'),
    path('tpcsignup/', user_views.tpcsignup, name='tpcsignup'),
    path('companysignup/', user_views.companysignup, name='companysignup'),
    path('collegesignup/', user_views.collegesignup, name='collegesignup'),

    path('studentclick/', user_views.studentclick, name='studentclick'),
    path('tpoclick/', user_views.tpoclick, name='tpoclick'),
    path('tpcclick/', user_views.tpcclick, name='tpcclick'),
    path('companyclick/', user_views.companyclick, name='companyclick'),
    path('collegeclick/', user_views.collegeclick, name='collegeclick'),

    path('afterlogin/', user_views.afterlogin, name='afterlogin'),

    path('login/', auth_views.LoginView.as_view(template_name='users/login.html', next_page='afterlogin'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(template_name='users/logout.html'), name='logout'),

    path('index/', app_view.index, name='index'),
    path('contact/', app_view.contact, name='contact'),


    path('', include('app.urls')),
]