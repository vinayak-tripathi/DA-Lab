from django.shortcuts import render
from .forms import NewJobForm, TPOJobUpdateForm, TPONewJobForm
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.shortcuts import render, redirect, get_object_or_404
from .models import Job, Applicants, Selected
from django.http import HttpResponseRedirect
from .models import AppliedJobs
from users.models import Student, Company, TPC, TPO


# Create your views here.
def index(request):
    return render(request, 'app/index.html')

def contact(request):
    return render(request, 'app/contact.html')

#Recruiter Commands
@login_required
def recruiter_home(request):
    return render(request, 'app/recruiterhome.html')

@login_required
def add_job(request):
    user = request.user
    recruiter = Company.objects.get(user=user)
    if request.method == "POST":
        form = NewJobForm(request.POST)
        if form.is_valid():
            data = form.save(commit=False)
            data.recruiter = recruiter
            data.save()
            return redirect('job-list')
    else:
        form = NewJobForm()
    context = {
        'form': form,
    }
    return render(request, 'app/add_job.html', context)


@login_required
def edit_job(request, slug):
    user = request.user
    job = get_object_or_404(Job, slug=slug)
    if request.method == "POST":
        form = NewJobForm(request.POST, instance=job)
        if form.is_valid():
            data = form.save(commit=False)
            data.save()
            return redirect('add-job-detail', slug)
    else:
        form = NewJobForm(instance=job)
    context = {
        'form': form,
        'job':job,
    }
    return render(request, 'app/edit_job.html', context)


@login_required
def job_detail_recruiter(request, slug):
    job = get_object_or_404(Job, slug=slug)
    context = {
        'job': job,
    }
    return render(request, 'app/job_detail_recruiter.html', context)


@login_required
def all_jobs(request):
    recruiter = Company.objects.get(user=request.user)
    jobs = Job.objects.filter(recruiter=recruiter).order_by('-date_posted')
    paginator = Paginator(jobs, 5)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    context = {
        'manage_jobs_page': "active",
        'jobs': page_obj,
        'rec_navbar': 1,
    }
    return render(request, 'app/job_posts.html', context)


@login_required
def applicant_list(request, slug):
    job = get_object_or_404(Job, slug=slug)
    applicants = Applicants.objects.filter(job=job).order_by('date_posted')
    profiles = []
    for applicant in applicants:
        profile = Student.objects.filter(user=applicant.applicant.user).first()
        profiles.append(profile)
    context = {
        'rec_navbar': 1,
        'profiles': profiles,
        'job': job,
    }
    return render(request, 'app/applicant_list.html', context)



@login_required
def select_applicant(request, can_id, job_id):
    job = get_object_or_404(Job, slug=job_id)
    profile = get_object_or_404(Student, slug=can_id)
    selected, created = Selected.objects.get_or_create(job=job, applicant=profile)
    applicant = Applicants.objects.filter(job=job, applicant=profile).first()
    applicant.delete()
    return HttpResponseRedirect('/recruiter/job/{}/applicants'.format(job.slug))


@login_required
def remove_applicant(request, can_id, job_id):
    job = get_object_or_404(Job, slug=job_id)
    profile = get_object_or_404(Student, slug=can_id)
    user = profile
    applicant = Applicants.objects.filter(job=job, applicant=profile).first()
    applicant.delete()
    return HttpResponseRedirect('/recruiter/job/{}/applicants'.format(job.slug))

@login_required
def selected_list(request, slug):
    job = get_object_or_404(Job, slug=slug)
    selected = Selected.objects.filter(job=job).order_by('date_posted')
    profiles = []
    for applicant in selected:
        profile = Student.objects.filter(user=applicant.applicant.user).first()
        profiles.append(profile)
    context = {
        'rec_navbar': 1,
        'profiles': profiles,
        'job': job,
    }
    return render(request, 'app/selected_list.html', context)



#Recruiter Commands End

#Applicant Commands

@login_required
def candidate_home(request):
    return render(request, 'app/candidatehome.html')

@login_required
def apply_job(request, slug):
    user = request.user
    student = Student.objects.get(user=user)
    job = get_object_or_404(Job, slug=slug)
    applied, created = AppliedJobs.objects.get_or_create(job=job, user=student)
    applicant, creation = Applicants.objects.get_or_create(
        job=job, applicant=student)
    return HttpResponseRedirect('/candidate/job/{}'.format(job.slug))


@login_required
def remove_job(request, slug):
    user = request.user
    job = get_object_or_404(Job, slug=slug)
    student = Student.objects.filter(user=user).first()
    deleted = AppliedJobs.objects.filter(job=job, user=student).first()
    deleted.delete()
    
    # saved_job = SavedJobs.objects.filter(job=job, user=user).first()
    # saved_job.delete()
    return HttpResponseRedirect('/candidate/job/{}'.format(job.slug))

# view to display applied jobs for that user
@login_required
def applied_jobs(request):
    student = Student.objects.filter(user=request.user).first()
    jobs = AppliedJobs.objects.filter(
        user=student).order_by('-date_posted')
    statuses = []
    for job in jobs:
        if Selected.objects.filter(job=job.job).filter(applicant=student).exists():
            statuses.append(0)
        elif Applicants.objects.filter(job=job.job).filter(applicant=student).exists():
            statuses.append(1)
        else:
            statuses.append(2)
    zipped = zip(jobs, statuses)
    return render(request, 'app/applied_jobs.html', {'zipped': zipped, 'candidate_navbar': 1})



def job_search_list(request):
    jobs = Job.objects.all().order_by('-date_posted')
    paginator = Paginator(jobs, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    context = {
        'manage_jobs_page': "active",
        'jobs': page_obj,
        'rec_navbar': 1,
    }
    
    return render(request, 'app/job_search.html', context)



# view to display details of a particular job
def job_detail_candidate(request, slug):
    job = get_object_or_404(Job, slug=slug)
    apply_button = 0
    profile = Student.objects.filter(user=request.user).first()
    if AppliedJobs.objects.filter(user=profile).filter(job=job).exists():
        apply_button = 1
    # if SavedJobs.objects.filter(user=request.user).filter(job=job).exists():
    #     save_button = 1
    # relevant_jobs = []
    # jobs1 = Job.objects.filter(
    #     company__icontains=job.company).order_by('-date_posted')
    # jobs2 = Job.objects.filter(
    #     job_type__icontains=job.job_type).order_by('-date_posted')
    # jobs3 = Job.objects.filter(
    #     title__icontains=job.title).order_by('-date_posted')
    # for i in jobs1:
    #     if len(relevant_jobs) > 5:
    #         break
    #     if i not in relevant_jobs and i != job:
    #         relevant_jobs.append(i)
    # for i in jobs2:
    #     if len(relevant_jobs) > 5:
    #         break
    #     if i not in relevant_jobs and i != job:
    #         relevant_jobs.append(i)
    # for i in jobs3:
    #     if len(relevant_jobs) > 5:
    #         break
    #     if i not in relevant_jobs and i != job:
    #         relevant_jobs.append(i)

    return render(request, 'app/job_detail_candidate.html', {'job': job, 'profile': profile, 'apply_button': apply_button, 'candidate_navbar': 1})

@login_required
def profile_view(request, slug):
    p = Student.objects.filter(slug=slug).first()
    you = p.user
    context = {
        'u': you,
        'profile': p,
    }
    return render(request, 'app/profile_view.html', context)




#Applicant Commands End



#TPO Commands Start

@login_required
def tpo_home(request):
    return render(request, 'app/tpohome.html')

@login_required
def all_jobs_posted(request):
    jobs = Job.objects.all().order_by('-date_posted')
    paginator = Paginator(jobs, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    context = {
        'manage_jobs_page': "active",
        'jobs': page_obj,
        'rec_navbar': 1,
    }
    
    return render(request, 'app/all_jobs_posted.html', context)


@login_required
def add_job_tpo(request):
    if request.method == "POST":
        form = TPONewJobForm(request.POST)
        if form.is_valid():
            data = form.save(commit=False)
            data.save()
            return redirect('all-jobs-tpo')
    else:
        form = TPONewJobForm()
    context = {
        'form': form,
    }
    return render(request, 'app/add_job_tpo.html', context)


@login_required
def edit_job_tpo(request, slug):
    job = get_object_or_404(Job, slug=slug)
    if request.method == "POST":
        form = TPONewJobForm(request.POST, instance=job)
        if form.is_valid():
            data = form.save(commit=False)
            data.save()
            return redirect('job-detail-tpo', slug)
    else:
        form = TPONewJobForm(instance=job)
    context = {
        'form': form,
        'job':job,
    }
    return render(request, 'app/edit_job_tpo.html', context)


@login_required
def job_detail_tpo(request, slug):
    job = get_object_or_404(Job, slug=slug)
    context = {
        'job': job,
    }
    return render(request, 'app/job_detail_tpo.html', context)


@login_required
def all_jobs_tpo(request):
    jobs = Job.objects.all().order_by('-date_posted')
    paginator = Paginator(jobs, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    context = {
        'manage_jobs_page': "active",
        'jobs': page_obj,
        'rec_navbar': 1,
    }
    
    return render(request, 'app/job_search_tpo.html', context)


@login_required
def applicant_list_tpo(request, slug):
    job = get_object_or_404(Job, slug=slug)
    applicants = Applicants.objects.filter(job=job).order_by('date_posted')
    profiles = []
    for applicant in applicants:
        profile = Student.objects.filter(user=applicant.applicant.user).first()
        profiles.append(profile)
    context = {
        'rec_navbar': 1,
        'profiles': profiles,
        'job': job,
    }
    return render(request, 'app/applicant_list_tpo.html', context)




@login_required
def selected_list_tpo(request, slug):
    job = get_object_or_404(Job, slug=slug)
    selected = Selected.objects.filter(job=job).order_by('date_posted')
    profiles = []
    for applicant in selected:
        profile = Student.objects.filter(user=applicant.applicant.user).first()
        profiles.append(profile)
    context = {
        'rec_navbar': 1,
        'profiles': profiles,
        'job': job,
    }
    return render(request, 'app/selected_list_tpo.html', context)

@login_required
def allcompanys(request):
    companys = Company.objects.all()
    paginator = Paginator(companys, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    context = {
        'manage_jobs_page': "active",
        'companys': page_obj,
        'rec_navbar': 1,
    }
    return render(request, 'app/company_list_tpo.html', context)

@login_required
def company_detail_tpo(request, slug):
    company = get_object_or_404(Company, user=slug)
    job = Job.objects.filter(recruiter=company)
    context = {
        'company': company,
        'job': job
    }
    return render(request, 'app/company_detail_tpo.html', context)

@login_required
def allstudents(request):
    students = Student.objects.all()
    paginator = Paginator(students, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    context = {
        'manage_jobs_page': "active",
        'students': page_obj,
        'rec_navbar': 1,
    }
    return render(request, 'app/student_list_tpo.html', context)

@login_required
def student_detail_tpo(request, slug):
    student = get_object_or_404(Student, user=slug)
    context = {
        'student': student,
    }
    return render(request, 'app/student_detail_tpo.html', context)

@login_required
def alltpcs(request):
    tpcs = TPC.objects.all()
    paginator = Paginator(tpcs, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    context = {
        'manage_jobs_page': "active",
        'tpcs': page_obj,
        'rec_navbar': 1,
    }
    return render(request, 'app/tpc_list_tpo.html', context)

@login_required
def tpc_detail_tpo(request, slug):
    tpc = get_object_or_404(TPC, user=slug)
    context = {
        'tpc': tpc,
    }
    return render(request, 'app/tpc_detail_tpo.html', context)

@login_required
def student_approval_list_tpo(request):
    students = Student.objects.filter(active=False)
    paginator = Paginator(students, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    context = {
        'manage_jobs_page': "active",
        'students': page_obj,
        'rec_navbar': 1,
    }
    return render(request, 'app/student_approval_list_tpo.html', context)

@login_required
def company_approval_list_tpo(request):
    companys = Company.objects.filter(active=False)
    paginator = Paginator(companys, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    context = {
        'manage_jobs_page': "active",
        'companys': page_obj,
        'rec_navbar': 1,
    }
    return render(request, 'app/company_approval_list_tpo.html', context)

@login_required
def tpc_approval_list_tpo(request):
    tpcs = TPC.objects.filter(active=False)
    paginator = Paginator(tpcs, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    context = {
        'manage_jobs_page': "active",
        'tpcs': page_obj,
        'rec_navbar': 1,
    }
    return render(request, 'app/tpc_approval_list_tpo.html', context)

@login_required
def approve_student(request, slug):
    student = get_object_or_404(Student, user=slug)
    student.active=True
    student.save()
    return HttpResponseRedirect('/tpo/approval/student')

@login_required
def approve_company(request, slug):
    company = get_object_or_404(Company, user=slug)
    company.active=True
    company.save()
    return HttpResponseRedirect('/tpo/approval/company')

@login_required
def approve_tpc(request, slug):
    tpc = get_object_or_404(TPC, user=slug)
    tpc.active=True
    tpc.save()
    return HttpResponseRedirect('/tpo/approval/tpc')

#TPO Commands End

#TPC Commands Start

@login_required
def tpc_home(request):
    return render(request, 'app/tpchome.html')


#TPC Commands End