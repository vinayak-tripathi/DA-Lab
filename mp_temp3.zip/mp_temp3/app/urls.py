from django.urls import path, include
from . import views

urlpatterns = [
    path('recruiter/', views.recruiter_home, name='recruiter-home'),
    path('recruiter/job/add', views.add_job, name='add-job'),
    path('recruiter/job/<slug>/edit/', views.edit_job, name='edit-job-post'),
    path('recruiter/job/<slug>', views.job_detail_recruiter, name='add-job-detail'),
    path('recruiter/job/', views.all_jobs, name='job-list'),

    path('recruiter/job/<slug>/applicants', views.applicant_list, name='applicant-list'),
    path('recruiter/job/<slug>/selected', views.selected_list, name='selected-list'),
    path('recruiter/job/<job_id>/select-applicant/<can_id>/',
         views.select_applicant, name='select-applicant'),
    path('recruiter/job/<job_id>>/remove-applicant/<can_id>/',
         views.remove_applicant, name='remove-applicant'),
    
    path('candidate/', views.candidate_home, name='candidate-home'),
    path('candidate/job/', views.job_search_list, name='job-search-list'),
    path('candidate/job/<slug>', views.job_detail_candidate, name='job-detail'),
    path('candidate/job/<slug>/apply/', views.apply_job, name='apply-job'),
    path('candidate/applied_job_list/', views.applied_jobs, name='applied-jobs'),
    path('candidate/job/<slug>/remove/', views.remove_job, name='remove-job'),
    path('candidate/profile/<slug>', views.profile_view, name='profile-view'),

    path('tpo/', views.tpo_home, name='tpo-home'),
    path('tpo/job/add', views.add_job_tpo, name='add-job-tpo'),
    path('tpo/job/<slug>/edit/', views.edit_job_tpo, name='edit-job-post-tpo'),
    path('tpo/job/', views.all_jobs_tpo, name='all-jobs-tpo'),
    path('tpo/job/<slug>', views.job_detail_tpo, name='job-detail-tpo'),
    path('tpo/job/<slug>/applicants', views.applicant_list_tpo, name='applicant-list-tpo'),
    path('tpo/job/<slug>/selected', views.selected_list_tpo, name='selected-list-tpo'),
    path('tpo/company/', views.allcompanys, name='all-company-tpo'),
    path('tpo/company/<slug>', views.company_detail_tpo, name='company-detail-tpo'),
    path('tpo/student/', views.allstudents, name='all-student-tpo'),
    path('tpo/student/<slug>', views.student_detail_tpo, name='student-detail-tpo'),
    path('tpo/tpc/', views.alltpcs, name='all-tpc-tpo'),
    path('tpo/tpc/<slug>', views.tpc_detail_tpo, name='tpc-detail-tpo'),
    path('tpo/approval/student/', views.student_approval_list_tpo, name='student-approval-list-tpo'),
    path('tpo/approval/student/<slug>', views.approve_student, name='approve-student-tpo'),
    path('tpo/approval/company/', views.company_approval_list_tpo, name='company-approval-list-tpo'),
    path('tpo/approval/company/<slug>', views.approve_company, name='approve-company-tpo'),
    path('tpo/approval/tpc/', views.tpc_approval_list_tpo, name='tpc-approval-list-tpo'),
    path('tpo/approval/tpc/<slug>', views.approve_tpc, name='approve-tpc-tpo'),


    path('tpc/', views.tpc_home, name='tpc-home'),





]