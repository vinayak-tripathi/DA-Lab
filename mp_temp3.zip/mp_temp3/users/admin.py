from django.contrib import admin

# Register your models here.
from .models import Student, TPO, Company, TPC, College

admin.site.register(Student)
admin.site.register(TPO)
admin.site.register(Company)
admin.site.register(TPC)
admin.site.register(College)