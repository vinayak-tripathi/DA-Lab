from django.shortcuts import render

# Create your views here.
# Create your views here.
from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib import messages
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.forms import UserCreationForm
from .forms import *
from django.contrib.auth.models import Group, User
from django.contrib.auth.decorators import login_required,user_passes_test
from .models import Student


#Clicks on homepage
#-------------------------------------START-----------------------------------------------------------------------------------#

def home(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect('afterlogin')
    return render(request, 'users/home.html')

def tpoclick(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect('afterlogin')
    return render(request, 'users/tpoclick.html')

def tpcclick(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect('afterlogin')
    return render(request, 'users/tpcclick.html')

def studentclick(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect('afterlogin')
    return render(request, 'users/studentclick.html')

def collegeclick(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect('afterlogin')
    return render(request, 'users/collegeclick.html')

def companyclick(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect('afterlogin')
    return render(request, 'users/companyclick.html')


#Clicks on homepage
#-------------------------------------END-----------------------------------------------------------------------------------#



def studentsignup(request):
    userForm = StudentRegistrationForm()
    studentForm = StudentProfileRegistrationForm()
    context = {'userForm':userForm, 'studentForm': studentForm}
    if request.method=="POST":
        userForm = StudentRegistrationForm(request.POST)
        studentForm = StudentProfileRegistrationForm(request.POST)
        if userForm.is_valid() and studentForm.is_valid():
            user = userForm.save()
            user.save()
            student = studentForm.save(commit=False)
            student.user = user
            student = student.save()
            my_student_group = Group.objects.get_or_create(name='STUDENT')
            my_student_group[0].user_set.add(user)
            return redirect('login')
    return render(request, 'users/studentsignup.html', context)

def tposignup(request):
    userForm = TPORegistrationForm()
    tpoForm = TPOProfileRegistrationForm()
    context = {'userForm':userForm, 'tpoForm': tpoForm}
    if request.method=="POST":
        userForm = TPORegistrationForm(request.POST)
        tpoForm = TPOProfileRegistrationForm(request.POST)
        if userForm.is_valid() and tpoForm.is_valid():
            user = userForm.save()
            user.save()
            tpo = tpoForm.save(commit=False)
            tpo.user = user
            tpo = tpo.save()
            my_tpo_group = Group.objects.get_or_create(name='TPO')
            my_tpo_group[0].user_set.add(user)
            return redirect('login')
    return render(request, 'users/tposignup.html', context)

def tpcsignup(request):
    userForm = TPCRegistrationForm()
    tpcForm = TPCProfileRegistrationForm()
    context = {'userForm':userForm, 'tpcForm': tpcForm}
    if request.method=="POST":
        userForm = TPCRegistrationForm(request.POST)
        tpcForm = TPCProfileRegistrationForm(request.POST)
        if userForm.is_valid() and tpcForm.is_valid():
            user = userForm.save()
            user.save()
            tpc = tpcForm.save(commit=False)
            tpc.user = user
            tpc = tpc.save()
            my_tpc_group = Group.objects.get_or_create(name='TPC')
            my_tpc_group[0].user_set.add(user)
            return redirect('login')
    return render(request, 'users/tpcsignup.html', context)

def companysignup(request):
    userForm = CompanyRegistrationForm()
    companyForm = CompanyProfileRegistrationForm()
    context = {'userForm':userForm, 'companyForm': companyForm}
    if request.method=="POST":
        userForm = CompanyRegistrationForm(request.POST)
        companyForm = CompanyProfileRegistrationForm(request.POST)
        if userForm.is_valid() and companyForm.is_valid():
            user = userForm.save()
            user.save()
            company = companyForm.save(commit=False)
            company.user = user
            company = company.save()
            my_company_group = Group.objects.get_or_create(name='COMPANY')
            my_company_group[0].user_set.add(user)
            return redirect('login')
    return render(request, 'users/companysignup.html', context)

def collegesignup(request):
    userForm = CollegeRegistrationForm()
    collegeForm = CollegeProfileRegistrationForm()
    context = {'userForm':userForm, 'collegeForm': collegeForm}
    if request.method=="POST":
        userForm = CollegeRegistrationForm(request.POST)
        collegeForm = CollegeProfileRegistrationForm(request.POST)
        if userForm.is_valid() and collegeForm.is_valid():
            user = userForm.save()
            user.save()
            college = collegeForm.save(commit=False)
            college.user = user
            college = college.save()
            my_college_group = Group.objects.get_or_create(name='COLLEGE')
            my_college_group[0].user_set.add(user)
            return redirect('login')
    return render(request, 'users/collegesignup.html', context)



@login_required(login_url='studentsignin')
def studentupdateprofile(request):
    student = Student.objects.get(user=request.user)
    print(student)
    user=User.objects.get(id=student.id)
    print(user)
    print(request.user.student)
    userForm=StudentRegistrationForm(instance=request.user)
    studentForm=StudentProfileUpdateForm(request.FILES,instance=student)
    mydict={'userForm':userForm,'studentForm':studentForm}
    if request.method=='POST':
        userForm=StudentRegistrationForm(request.POST,instance=request.user)
        studentForm=StudentProfileUpdateForm(request.POST,request.FILES,instance=student)
        if userForm.is_valid() and studentForm.is_valid():
            user=userForm.save()
            user.save()
            student=studentForm.save(commit=False)
            student.save()
            return redirect('home')
    return render(request,'users/studentupdateprofile.html',context=mydict)

def register(request):
    if request.method == 'POST':
        form = StudentRegistrationForm(request.POST)
        if form.is_valid():
            form.save()

            messages.success(request, f'Your account has been created. You can log in now!')    
            return redirect('login')
    else:
        form = StudentRegistrationForm()

    context = {'form': form}
    return render(request, 'users/register.html', context)



#Checking if the user is a patient/doctor/admin
#-------------------------------------START-----------------------------------------------------------------------------------#



def is_student(user):
    return user.groups.filter(name='STUDENT').exists()

def is_tpo(user):
    return user.groups.filter(name='TPO').exists()

def is_tpc(user):
    return user.groups.filter(name='TPC').exists()

def is_company(user):
    return user.groups.filter(name='COMPANY').exists()

def is_college(user):
    return user.groups.filter(name='COLLEGE').exists()



#Checking if the user is a patient/doctor/admin
#-------------------------------------END-----------------------------------------------------------------------------------#






#Rerouting to the dashboard after logging in
#-------------------------------------START-----------------------------------------------------------------------------------#



def afterlogin(request):
    if is_student(request.user):
        approval = Student.objects.all().filter(user_id = request.user.id, active=True)
        if approval:
            return redirect('candidate-home')
        else:
            return render(request, 'users/waitforapproval.html')

    elif is_tpo(request.user):
        approval = TPO.objects.all().filter(user_id = request.user.id, active=True)
        if approval:
            return redirect('tpo-home')
        else:
            return render(request, 'users/waitforapproval.html')
    
    elif is_tpc(request.user):
        approval = TPC.objects.all().filter(user_id = request.user.id, active=True)
        if approval:
            return redirect('tpc-home')
        else:
            return render(request, 'users/waitforapproval.html')
    
    elif is_company(request.user):
        approval = Company.objects.all().filter(user_id = request.user.id, active=True)
        if approval:
            return redirect('recruiter-home')
        else:
            return render(request, 'users/waitforapproval.html')
    
    elif is_college(request.user):
        approval = College.objects.all().filter(user_id = request.user.id, active=True)
        if approval:
            return redirect('home')
        else:
            return render(request, 'users/waitforapproval.html')
    



#Rerouting to the dashboard after logging in
#-------------------------------------END-----------------------------------------------------------------------------------#



# def studenthome(request):
#     if request.user.is_authenticated:
#         return 