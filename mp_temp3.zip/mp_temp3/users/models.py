from email.policy import default
from django.db import models

# Create your models here.
from django.db import models
from autoslug import AutoSlugField


# Create your models here.
from django.contrib.auth.models import AbstractUser, User
import datetime
from django.core.validators import MaxValueValidator, MinValueValidator

BRANCHES = (
   ('COMPS', 'COMPS'),
   ('IT', 'IT'),
   ('EXTC', 'EXTC'),
   ('ETRX', 'ETRX'),
   ('AIML', 'AIML'),
   ('DS', 'DS'),
)

def current_year():
    return datetime.date.today().year

def max_value_current_year(value):
    return MaxValueValidator(current_year()+4)(value) 


class TPO(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    mobile = models.CharField(max_length=500)
    active = models.BooleanField(default=False)
    @property
    def get_name(self):
        return self.user.first_name + ' ' + self.user.last_name
    @property
    def get_id(self):
        return self.user.id
    def __str__(self):
        return '{} {}'.format(self.user.first_name, self.user.last_name)


class TPC(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    mobile = models.CharField(max_length=500)
    active = models.BooleanField(default=False)
    @property
    def get_name(self):
        return self.user.first_name + ' ' + self.user.last_name
    @property
    def get_id(self):
        return self.user.id
    def __str__(self):
        return '{} {}'.format(self.user.first_name, self.user.last_name)


class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    uid = models.CharField(max_length=500,blank=True, null=True)
    yop = models.IntegerField(validators=[MinValueValidator(1984), max_value_current_year],blank=True, null=True)
    branch = models.CharField(max_length = 20,choices = BRANCHES, null=True, blank=True, default='NA')
    division = models.CharField(max_length=500, blank=True, null=True, default='NA')
    sem1cgpa = models.FloatField(blank=True, null=True, default=0)
    sem2cgpa = models.FloatField(blank=True, null=True, default=0)
    sem3cgpa = models.FloatField(blank=True, null=True, default=0)
    sem4cgpa = models.FloatField(blank=True, null=True, default=0)
    sem5cgpa = models.FloatField(blank=True, null=True, default=0)
    sem6cgpa = models.FloatField(blank=True, null=True, default=0)
    sem7cgpa = models.FloatField(blank=True, null=True, default=0)
    sem8cgpa = models.FloatField(blank=True, null=True, default=0)
    sem1marksheet = models.FileField(upload_to ='uploads/sem1/',blank=True, null=True)
    sem2marksheet = models.FileField(upload_to ='uploads/sem2/',blank=True, null=True)
    sem3marksheet = models.FileField(upload_to ='uploads/sem3/',blank=True, null=True)
    sem4marksheet = models.FileField(upload_to ='uploads/sem4/',blank=True, null=True)
    sem5marksheet = models.FileField(upload_to ='uploads/sem5/',blank=True, null=True)
    sem6marksheet = models.FileField(upload_to ='uploads/sem6/',blank=True, null=True)
    sem7marksheet = models.FileField(upload_to ='uploads/sem7/',blank=True, null=True)
    sem8marksheet = models.FileField(upload_to ='uploads/sem8/',blank=True, null=True)
    aadhar_no = models.IntegerField(blank=True, null=True, default=0)
    aadhar_doc = models.FileField(upload_to = 'uploads/aadhar/',blank=True, null=True)
    class_10_marks = models.FloatField(blank=True, null=True, default=0)
    class_12_marks = models.FloatField(blank=True, null=True, default=0)
    class10_marksheet = models.FileField(upload_to = 'uploads/marksheet/class10',blank=True, null=True)
    class12_marksheet = models.FileField(upload_to = 'uploads/marksheet/class12',blank=True, null=True)
    profile_pic = models.ImageField(upload_to = 'uploads/user/profile_pic/',blank=True, null=True)
    date_created = models.DateTimeField(auto_now_add=True)
    last_modified = models.DateTimeField(auto_now=True)
    skills = models.CharField(max_length=500,blank=True, null=True, default='NA')
    active = models.BooleanField(default=False)
    slug = AutoSlugField(populate_from='user', unique=True)
    @property
    def get_name(self):
        return self.user.first_name + ' ' + self.user.last_name
    @property
    def get_id(self):
        return self.user.id
    def __str__(self):
        return '{} {}'.format(self.user.first_name, self.user.last_name)

class Company(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    company_name = models.CharField(max_length = 500)
    mobile = models.CharField(max_length=500)
    active = models.BooleanField(default=False)
    @property
    def get_name(self):
        return self.user.first_name + ' ' + self.user.last_name
    @property
    def get_id(self):
        return self.user.id
    def __str__(self):
        return '{} {} - {}'.format(self.user.first_name, self.user.last_name, self.company_name)
    @property
    def get_company_name(self):
        return self.company_name

class College(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    college_name = models.CharField(max_length = 500)
    mobile = models.CharField(max_length=500)
    active = models.BooleanField(default=False)
    @property
    def get_name(self):
        return self.user.first_name + ' ' + self.user.last_name
    @property
    def get_id(self):
        return self.user.id
    def __str__(self):
        return '{}'.format(self.college_name)
