from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import *


class StudentRegistrationForm(UserCreationForm):
    first_name = forms.CharField(max_length=101)
    last_name = forms.CharField(max_length=101)
    email = forms.EmailField()

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2']
        # fields = '__all__'

class StudentProfileRegistrationForm(forms.ModelForm):
    class Meta:
        model = Student
        # fields = '__all__'
        fields = ['uid','yop']

class StudentProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['uid','yop','branch','division','sem1cgpa','sem2cgpa','sem3cgpa','sem4cgpa','sem5cgpa','sem6cgpa','sem7cgpa','sem8cgpa','sem1marksheet','sem2marksheet','sem3marksheet','sem4marksheet','sem5marksheet','sem6marksheet','sem7marksheet','sem8marksheet','aadhar_no','aadhar_doc','class_10_marks','class_12_marks','class10_marksheet','class12_marksheet','profile_pic','skills']


class TPORegistrationForm(UserCreationForm):
    first_name = forms.CharField(max_length=101)
    last_name = forms.CharField(max_length=101)
    email = forms.EmailField()

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2']

class TPOProfileRegistrationForm(forms.ModelForm):
    class Meta:
        model = TPO
        # fields = '__all__'
        fields = ['mobile']

class TPCRegistrationForm(UserCreationForm):
    first_name = forms.CharField(max_length=101)
    last_name = forms.CharField(max_length=101)
    email = forms.EmailField()

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2']

class TPCProfileRegistrationForm(forms.ModelForm):
    class Meta:
        model = TPC
        # fields = '__all__'
        fields = ['mobile']

class CompanyRegistrationForm(UserCreationForm):
    first_name = forms.CharField(max_length=101)
    last_name = forms.CharField(max_length=101)
    email = forms.EmailField()

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2']

class CompanyProfileRegistrationForm(forms.ModelForm):
    class Meta:
        model = Company
        # fields = '__all__'
        fields = ['company_name', 'mobile']
class CollegeRegistrationForm(UserCreationForm):
    first_name = forms.CharField(max_length=101)
    last_name = forms.CharField(max_length=101)
    email = forms.EmailField()

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2']

class CollegeProfileRegistrationForm(forms.ModelForm):
    class Meta:
        model = College
        # fields = '__all__'
        fields = ['college_name', 'mobile']

